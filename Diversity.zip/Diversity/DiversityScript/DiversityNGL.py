# Libraries
from colorama import Fore, init
from random import choice
from time import sleep
from os import system
import requests
import re

# Variables
Messages = [
    'Diversity beamed you!',
    'Watch out! You might want to disable notifications.',
    'Uh oh, i think something weird is happening...',
    'See you learn something new everyday, don\'t use NGL :)',
    'How did you not think about this?!?!',
    'Have fun!',
    'This is a randomly generated message composed of 60 letters!',
    'I don\'t know if you have heard about Diversity but i think they heard about you!',
    'Huh? Is something wrong?',
    'You might want to check your notifications settings.',
    'Come on this isn\'t that bad...',
    'You better watch out, you better not cry, becouse Diversity is coming to town!',
    'TIP: disable notifications.',
    'You signed up for this ;)',
    'You knew something like this could happen... But you did it anyways!',
    'Tell everyone about OHR, they might spare you!',
    'NGL is kinda cringe not gonna lie.',
    'OHR is watching... 👀'
]
Targets = ['https://ngl.link/il_forna_p_q/yourcrush']

# Start
system('title DiversityNGL ^| OHR')
system('cls')
init(autoreset=True)

print(f'''{Fore.LIGHTMAGENTA_EX}   ___  _                  _ __       _  _________ 
  / _ \(_)  _____ _______ (_) /___ __/ |/ / ___/ / 
 / // / / |/ / -_) __(_-</ / __/ // /    / (_ / /__
/____/_/|___/\__/_/ /___/_/\__/\_, /_/|_/\___/____/
                              /___/                  OHR
''')
print(f'{Fore.LIGHTGREEN_EX}Main target : scuole_villafranca\n')

TargetCounter = 0
StatusCounter = 0
print(f'{Fore.YELLOW}Searching for targets...')
with open('output/followers_info_dump.txt', 'rb') as Unfiltered:
    UnfilteredLines = Unfiltered.readlines()
    for UnfilteredLine in UnfilteredLines:
        StatusCounter += 1
        if StatusCounter >= 100:
            print(f'{Fore.LIGHTBLACK_EX} - Status : Running!')
            StatusCounter = 0
        Username = ((str(re.search(b'\'username\': \'(.*?)\', \'full_name\':', UnfilteredLine).group(1))[2:])[:-1]).replace(' ', '')
        Exists = requests.get(f'https://ngl.link/{Username}', headers={'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; rv:91.0) Gecko/20100101 Firefox/91.0'})
        if 200 <= Exists.status_code <= 299:
            TargetCounter += 1
            Targets.append(f'https://ngl.link/{Username}')
            print(f'{Fore.LIGHTGREEN_EX} - Found target : {TargetCounter}')
        elif Exists.status_code == 429:
            Cooldown = int(Exists.headers['Retry-After'])
            print(f'{Fore.LIGHTBLACK_EX} - Status : Rate limited waiting {Cooldown} seconds...')
            sleep(Cooldown)
            Exists = requests.get(f'https://ngl.link/{Username}', headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; rv:91.0) Gecko/20100101 Firefox/91.0'})
            if 200 <= Exists.status_code <= 299:
                TargetCounter += 1
                Targets.append(f'https://ngl.link/{Username}')
                print(f'{Fore.LIGHTGREEN_EX} - Found target : {TargetCounter}')
        sleep(2.6)
    Unfiltered.close()
if TargetCounter == 1:
    print(f'{Fore.LIGHTGREEN_EX}Finished! Found 1 target.')
else:
    print(f'{Fore.LIGHTGREEN_EX}Finished! Found {TargetCounter} targets.')

StatusCounter = 0
print(f'{Fore.YELLOW}Spamming targets...')
while True:
    for Target in Targets:
        for _ in range(100):
            Payload = {'question': f'{choice(Messages)} | OHR'}
            try:
                Request = requests.post(Target, data=Payload, timeout=5)
                if 200 <= Request.status_code <= 299:
                    StatusCounter += 1
                    print(f'{Fore.LIGHTGREEN_EX} - Message sent : {Target} : {StatusCounter}')
                elif Request.status_code == 429:
                    Cooldown = int(Request.headers['Retry-After'])
                    print(f'{Fore.LIGHTBLACK_EX} - Status : Rate limited waiting {Cooldown} seconds...')
                    sleep(Cooldown)
                    Request = requests.post(Target, data=Payload, timeout=5)
                    if 200 <= Request.status_code <= 299:
                        StatusCounter += 1
                        print(f'{Fore.LIGHTGREEN_EX} - Message sent : {Target} : {StatusCounter}')
            except (Exception,):
                break
        sleep(33)
